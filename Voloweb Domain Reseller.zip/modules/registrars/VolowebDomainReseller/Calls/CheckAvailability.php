<?php
namespace ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Core\Call;

/**
 * Description of CheckAvailability
 *
 * @author inbs
 */
class CheckAvailability extends Call
{
    public $action = "domains/lookup";
    
    public $type = parent::TYPE_POST;
}
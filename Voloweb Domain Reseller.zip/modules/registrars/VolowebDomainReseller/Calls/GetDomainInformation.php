<?php

namespace ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Calls;

use ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Core\Call;

class GetDomainInformation extends Call
{
    public $action = 'domains/:domain/information';

    public $type = parent::TYPE_GET;
}
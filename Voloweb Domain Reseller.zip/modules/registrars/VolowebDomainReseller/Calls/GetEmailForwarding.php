<?php
namespace ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Core\Call;

/**
 * Description of GetEmailForwarding
 *
 * @author inbs
 */
class GetEmailForwarding extends Call
{
    public $action = "domains/:domain/email";
    
    public $type = parent::TYPE_GET;
}
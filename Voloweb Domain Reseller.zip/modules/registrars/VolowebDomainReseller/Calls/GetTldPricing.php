<?php

namespace ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Calls;

use ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Core\Call;

class GetTldPricing extends Call
{
    public $action = "tlds/pricing";

    public $type = parent::TYPE_GET;
}
<?php
namespace ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Core\Call;

/**
 * Description of RequestDelete
 *
 * @author inbs
 */
class RequestDelete extends Call
{
    public $action = "domains/:domain/delete";
    
    public $type = parent::TYPE_POST;
}
<?php
namespace ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class SaveDns extends Call
{
    public $action = "domains/:domain/dns";
    
    public $type = parent::TYPE_POST;
}
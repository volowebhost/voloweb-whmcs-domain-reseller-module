<?php
namespace ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\VolowebDomainReseller\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class ToggleIdProtect extends Call
{
    public $action = "domains/:domain/protectid";
    
    public $type = parent::TYPE_POST;
}